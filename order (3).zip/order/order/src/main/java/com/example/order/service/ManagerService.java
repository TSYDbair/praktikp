package com.example.order.service;

public class ManagerService {
}
