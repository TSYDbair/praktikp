package com.example.order.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Managers {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idManager;
    private String FIO;
    private String Email;
    private String Number;
    private String Address;

    public Managers(Long idClient, String FIO, String Email, String Number, String Address) {
        this.idManager = idClient;
        this.FIO = FIO;
        this.Email = Email;
        this.Number = Number;
        this.Address = Address;
    }
    public Managers(String FIO, String Email, String Number, String Address){
        this.FIO = FIO;
        this.Email = Email;
        this.Number = Number;
        this.Address = Address;
    }
    public Managers() {

    }
    public Long getId() {return idManager;}
    public void setId(Long idClient) {this.idManager = idClient;}
    public String getFIO() {return FIO;}
    public void setFIO(String FIO) {this.FIO = FIO;}
    public String getNumber() {return Number;}
    public void setNumber(String Number) {this.Number = Number;}
    public String getAddress() {return Address;}
    public void setAddress(String Address) {this.Address = Address;}
    public String getEmail() {return Email;}
    public void setEmail(String Email) {this.Email = Email;}
    @Override
    public String toString() {
        return "Order{" +
                "id=" + idManager +
                ", Client='" + FIO + '\'' +
                ", Manager='" + Number + '\'' +
                ", Model='" + Email + '\'' +
                ", Size=" + Address + '\'' +
                '}';
    }
}
