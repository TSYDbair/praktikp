package com.example.order.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.order.model.Clients;
import com.example.order.repository.ClientRepository;

@RestController
@RequestMapping("/api/Clients")
public class ClientController {
    
    private final ClientRepository clientRepository;
    public ClientController(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }


    @GetMapping("/all")
    public List<Clients> getAllClients() {
        return clientRepository.findAll();
    }
   

    @GetMapping("/{id}")
    public ResponseEntity<Clients> getClientById(@PathVariable Long id) {
        return clientRepository.findById(id)
                .map(client -> ResponseEntity.ok().body(client))
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Clients createClient(@RequestBody Clients client) {
        return clientRepository.save(client);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Clients> updateClient(@PathVariable Long id, @RequestBody Clients clientDetails) {
        return clientRepository.findById(id)
                .map(client -> {
                    client.setFIO(clientDetails.getFIO());
                    client.setEmail(clientDetails.getEmail());
                    client.setNumber(clientDetails.getNumber());
                    client.setAddress(clientDetails.getAddress());
                    Clients updatedClient = clientRepository.save(client);
                    return ResponseEntity.ok().body(updatedClient);
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClient(@PathVariable Long id) {
        // Проверка, существует ли клиент с данным ID
        if (clientRepository.existsById(id)) {
            clientRepository.deleteById(id); // Удаление клиента по ID
            return ResponseEntity.ok().build(); // Возвращаем статус 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Возвращаем статус 404 Not Found
        }
    }
}
