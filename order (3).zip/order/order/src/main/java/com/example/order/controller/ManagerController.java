package com.example.order.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.model.Managers;
import com.example.order.repository.ManagerRepository;

@RestController
@RequestMapping("/api/Managers")
public class ManagerController {
    private final ManagerRepository managerRepository;
    public ManagerController(ManagerRepository managerRepository) {
        this.managerRepository = managerRepository;
    }



    @GetMapping("/all")
    public List<Managers> getAllOrders() {
        return managerRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Managers> getOrderById(@PathVariable Long id) {
        return managerRepository.findById(id)
                .map(order -> ResponseEntity.ok().body(order))
                .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Managers createOrder(@RequestBody Managers order) {
        return managerRepository.save(order);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Managers> updateOrder(@PathVariable Long id, @RequestBody Managers orderDetails) {
        return managerRepository.findById(id)
                .map(manager -> {
                    manager.setFIO(orderDetails.getFIO());
                    manager.setEmail(orderDetails.getEmail());
                    manager.setNumber(orderDetails.getNumber());
                    manager.setAddress(orderDetails.getAddress());
                    Managers updatedOrder = managerRepository.save(manager);
                    return ResponseEntity.ok().body(updatedOrder);
                }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClient(@PathVariable Long id) {
        // Проверка, существует ли клиент с данным ID
        if (managerRepository.existsById(id)) {
            managerRepository.deleteById(id); // Удаление клиента по ID
            return ResponseEntity.ok().build(); // Возвращаем статус 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Возвращаем статус 404 Not Found
        }
    }
}
